# GabBrowser — Registro de decisões técnicas

Este arquivo guarda o que foi decidido e por quê, para o projeto não perder o fio entre sessões.
Cada decisão nova entra no fim, com data.

## D1 — Motor de navegação: Android System WebView (2026-11-10)

Avaliados: GeckoView (Mozilla) e Android System WebView (Chromium).

| Critério | WebView do sistema | GeckoView |
|---|---|---|
| Atualizações de segurança | Chegam pela Play Store, sem recompilar o app | Ficam presas à versão embutida no APK; exige novo APK a cada ~4 semanas |
| Tamanho do APK | Poucos MB | Dezenas de MB por arquitetura |
| Consumo de memória | Motor compartilhado com o sistema | Motor próprio carregado pelo app |
| Compatibilidade com sites | Igual ao Chrome | Muito boa, com exceções pontuais |
| Bloqueio de rastreadores nativo | Não tem; precisa ser construído (GabShield) | Tem (Enhanced Tracking Protection) |
| Modo anônimo isolado | Via perfis do androidx.webkit, quando o WebView do aparelho suporta | Nativo |
| Manutenção | API estável há anos | API muda a cada versão |

**Decisão:** WebView do sistema.

**Motivo principal:** o projeto é mantido por uma pessoa, sem ciclo fixo de lançamentos. Com GeckoView, cada
mês sem novo APK deixaria o navegador com falhas de motor já públicas. Com o WebView, as correções do
Chromium chegam ao aparelho mesmo que o GabBrowser não seja atualizado.

**Custo assumido:** o bloqueio de rastreadores e anúncios (GabShield/GabClean) terá de ser implementado
pelo app, interceptando requisições; a proteção contra fingerprinting será limitada ao que o WebView permite;
o isolamento do modo anônimo depende da API de perfis do WebView e precisa de alternativa para aparelhos
sem suporte.

**Saída prevista:** as telas só conhecem a interface `EngineSession` (`core/engine`). Trocar para GeckoView
no futuro significa escrever outra implementação dessa interface.

## D2 — Somente HTTPS na Etapa 1 (2026-11-10)

`usesCleartextTraffic=false` e `network_security_config` sem tráfego em texto puro. Toda navegação `http://`
é reescrita para `https://`. Se o site devolver para http, a página mostra "Site sem HTTPS" e não abre.

Sites que só existem em http ficam inacessíveis nesta etapa. O acesso com aviso explícito e exceção por site
entra com o GabShield (Etapa 3), que é onde ficam as demais decisões de conexão.

## D3 — Erros de certificado não têm botão "continuar" (2026-11-10)

`onReceivedSslError` sempre cancela a carga. Não existe caminho de código que chame `proceed()`.
Certificados instalados pelo usuário também não são aceitos (`trust-anchors` só com `system`).

## D4 — Política de esquemas de URL (2026-11-10)

`NavigationPolicy` (em `core/common`, com testes): https permitido; http reescrito; `about:blank` permitido;
todo o resto bloqueado (`file:`, `content:`, `javascript:`, `data:`, `intent:`, `market:`, `tel:`, `mailto:`).

Consequência: links que abririam outros apps (telefone, e-mail, loja) não funcionam ainda. Entram na Etapa 3
com confirmação do usuário antes de sair do navegador.

Na barra de endereço, texto com esquema diferente de http/https vira pesquisa, assim como endereços no
formato `usuario@host`.

## D5 — Configuração do WebView (2026-11-10)

- JavaScript ligado (necessário para a web atual); nenhuma `addJavascriptInterface`.
- Acesso a arquivos e a content providers desligado.
- Conteúdo misto bloqueado (`MIXED_CONTENT_NEVER_ALLOW`).
- Cookies de terceiros desligados.
- Câmera, microfone e localização: todo pedido é negado até existir a tela de permissões (Etapa 3).
- Janelas pop-up por script desligadas.
- Navegação Segura do WebView ligada; envio de métricas do WebView desligado.

## D6 — Arquitetura em módulos (2026-11-10)

- `core/common`: Kotlin puro, sem Android. Classificador da barra de endereço, mecanismos de pesquisa e
  política de navegação. É onde ficam os testes unitários.
- `core/engine`: contrato do motor e implementação WebView.
- `core/data`: Room (histórico, favoritos) e DataStore (preferências).
- `core/designsystem`: cores, tema claro/escuro e logotipo em vetor.
- `app`: telas em Jetpack Compose e ligação entre os módulos.

Sem framework de injeção de dependência por enquanto: `GabApplication` cria os repositórios.
A Activity declara `configChanges` para que a rotação da tela não destrua o WebView.

## D7 — Dados locais (2026-11-10)

Histórico e favoritos em Room, preferências em DataStore, tudo em armazenamento interno do app.
Backup em nuvem e transferência entre aparelhos desligados (`allowBackup=false` + `data_extraction_rules`).
Única permissão no manifesto: `INTERNET`. Sem analytics e sem SDK de terceiros.

## D8 — Versões e build (2026-11-10)

minSdk 26 (Android 8.0), targetSdk/compileSdk 35. AGP 8.7.3, Gradle 8.9, Kotlin 2.0.21, Compose BOM 2024.12.01.
São versões estáveis e compatíveis entre si, mas não as mais novas; o Dependabot (`.github/dependabot.yml`)
abre pedidos de atualização semanalmente. Atualizar tudo e conferir avisos de vulnerabilidade faz parte da Etapa 5.

Package: `com.gabbrowser.android`. versionCode 1, versionName 0.1.0.

Compilação pelo GitHub Actions (`.github/workflows/build.yml`), que roda os testes de `core/common` e gera o
APK de depuração. A assinatura de release fica para a Etapa 5, com a chave fora do repositório.

## Pendências conhecidas para a auditoria de segurança (Etapa 5)

- A barra de endereço passa a mostrar a URL de destino assim que a carga começa; conferir em aparelho se há
  janela em que o conteúdo antigo aparece com o endereço novo.
- Confirmar em aparelho a ordem dos eventos do WebView em erro de certificado (o cadeado nunca pode aparecer
  numa página de erro).
- Confirmar que o WebView do aparelho respeita `trust-anchors` do `network_security_config`.
- Diálogos JavaScript (`alert`, `confirm`) usam a janela padrão do WebView; avaliar limite contra abuso.
- A Navegação Segura depende dos serviços do Google no aparelho; sem eles não há proteção contra phishing
  nesta etapa.
