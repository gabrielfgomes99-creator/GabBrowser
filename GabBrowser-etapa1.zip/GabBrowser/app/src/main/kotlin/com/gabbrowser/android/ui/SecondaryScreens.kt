package com.gabbrowser.android.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.gabbrowser.core.common.SearchEngine
import com.gabbrowser.core.data.SettingsRepository
import com.gabbrowser.core.data.ThemeMode
import com.gabbrowser.core.data.UserSettings
import com.gabbrowser.core.engine.PageState
import com.gabbrowser.core.engine.WebViewSession
import kotlinx.coroutines.launch

@Composable
private fun ScreenColumn(title: String, content: @Composable () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp),
    ) {
        Spacer(Modifier.height(24.dp))
        Text(
            text = title,
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground,
        )
        Spacer(Modifier.height(16.dp))
        content()
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun Note(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
}

@Composable
private fun GroupTitle(text: String) {
    Text(
        text = text,
        modifier = Modifier.padding(top = 20.dp, bottom = 6.dp),
        style = MaterialTheme.typography.titleSmall,
        fontWeight = FontWeight.SemiBold,
        color = MaterialTheme.colorScheme.primary,
    )
}

// ---------------------------------------------------------------- Abas

@Composable
fun TabsScreen(page: PageState, onOpenCurrent: () -> Unit) {
    ScreenColumn(title = "Abas") {
        if (page.url.isEmpty()) {
            Note("Nenhuma página aberta.")
        } else {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .clickable(onClickLabel = "Voltar para a página", onClick = onOpenCurrent),
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surface,
                shadowElevation = 2.dp,
            ) {
                Column(Modifier.padding(16.dp)) {
                    Text(
                        text = page.title.ifBlank { displayHost(page.url) },
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        text = displayHost(page.url),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        Note("Esta versão trabalha com uma aba. Várias abas, grupos e abas anônimas chegam na Etapa 2.")
    }
}

// ---------------------------------------------------------------- Ferramentas

private data class ToolStatus(val name: String, val description: String, val stage: String)

private val TOOLS = listOf(
    ToolStatus("GabShield", "Central de segurança: rastreadores, phishing, permissões.", "Etapa 3"),
    ToolStatus("GabClean", "Bloqueio de anúncios e elementos invasivos.", "Etapa 3"),
    ToolStatus("GabAI", "Assistente para resumir, explicar e traduzir páginas.", "Etapa 4"),
    ToolStatus("GabFlow", "Organização e grupos de abas.", "Etapa 4"),
    ToolStatus("GabOne", "Limpeza de dados com um toque.", "Etapa 4"),
    ToolStatus("GabReader", "Modo leitura.", "Etapa 4"),
    ToolStatus("GabScan", "Leitor de QR Code com verificação do destino.", "Etapa 4"),
    ToolStatus("GabSaver", "Economia de dados.", "Etapa 4"),
    ToolStatus("GabDownload", "Gerenciador de downloads.", "Etapa 2"),
)

@Composable
fun ToolsScreen() {
    ScreenColumn(title = "Ferramentas") {
        Note("Nenhuma destas ferramentas está ativa ainda. Cada uma entra na etapa indicada.")
        Spacer(Modifier.height(8.dp))
        TOOLS.forEach { tool ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        text = tool.name,
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onBackground,
                    )
                    Text(
                        text = tool.description,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Spacer(Modifier.width(12.dp))
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                ) {
                    Text(
                        text = tool.stage,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }
}

// ---------------------------------------------------------------- Configurações

@Composable
fun SettingsScreen(settings: UserSettings, settingsRepository: SettingsRepository) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val appVersion = remember {
        runCatching {
            context.packageManager.getPackageInfo(context.packageName, 0).versionName
        }.getOrNull() ?: "desconhecida"
    }
    val engine = remember { WebViewSession.engineDescription(context) ?: "não identificado" }

    ScreenColumn(title = "Configurações") {
        GroupTitle("Mecanismo de pesquisa")
        SearchEngine.entries.forEach { option ->
            RadioRow(
                label = option.displayName,
                selected = settings.searchEngine == option,
                onSelect = { scope.launch { settingsRepository.setSearchEngine(option) } },
            )
        }

        GroupTitle("Tema")
        ThemeMode.entries.forEach { option ->
            RadioRow(
                label = option.displayName,
                selected = settings.themeMode == option,
                onSelect = { scope.launch { settingsRepository.setThemeMode(option) } },
            )
        }

        GroupTitle("Privacidade")
        Note(
            "Histórico e favoritos ficam somente neste aparelho. O GabBrowser não tem " +
                "analytics nem envia dados de uso. Os sites que você visita e o mecanismo de " +
                "pesquisa escolhido continuam vendo seus acessos.",
        )

        GroupTitle("Sobre")
        Note("GabBrowser $appVersion")
        Note("Motor: Android System WebView ($engine)")
    }
}

@Composable
private fun RadioRow(label: String, selected: Boolean, onSelect: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .selectable(selected = selected, role = Role.RadioButton, onClick = onSelect)
            .padding(vertical = 10.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        RadioButton(selected = selected, onClick = null)
        Spacer(Modifier.width(12.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onBackground,
        )
    }
}
