package com.gabbrowser.android

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.gabbrowser.android.ui.GabApp

class MainActivity : ComponentActivity() {

    private lateinit var controller: BrowserController

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val app = application as GabApplication
        controller = BrowserController(this, app.sites, app.appScope)

        setContent {
            GabApp(
                controller = controller,
                settingsRepository = app.settings,
                sites = app.sites,
            )
        }
    }

    override fun onResume() {
        super.onResume()
        controller.onResume()
    }

    override fun onPause() {
        controller.onPause()
        super.onPause()
    }

    override fun onDestroy() {
        controller.destroy()
        super.onDestroy()
    }
}
