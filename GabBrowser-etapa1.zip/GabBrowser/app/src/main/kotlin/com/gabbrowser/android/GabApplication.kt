package com.gabbrowser.android

import android.app.Application
import com.gabbrowser.core.data.GabData
import com.gabbrowser.core.data.SettingsRepository
import com.gabbrowser.core.data.SiteRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

/** Dependências do app, criadas sob demanda. Sem analytics e sem SDKs de terceiros. */
class GabApplication : Application() {

    val appScope: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    val settings: SettingsRepository by lazy { SettingsRepository(this) }

    val sites: SiteRepository by lazy { GabData.siteRepository(this) }
}
