package com.gabbrowser.android.ui

import android.app.Activity
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.gabbrowser.android.BrowserController
import com.gabbrowser.core.common.UrlInputClassifier
import com.gabbrowser.core.data.SettingsRepository
import com.gabbrowser.core.data.SiteRepository
import com.gabbrowser.core.data.ThemeMode
import com.gabbrowser.core.data.UserSettings
import com.gabbrowser.core.designsystem.GabTheme
import com.gabbrowser.core.engine.EngineEvent

enum class Screen { HOME, BROWSER, TABS, TOOLS, SETTINGS }

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun GabApp(
    controller: BrowserController,
    settingsRepository: SettingsRepository,
    sites: SiteRepository,
) {
    val settings by settingsRepository.settings.collectAsStateWithLifecycle(initialValue = UserSettings())
    val darkTheme = when (settings.themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    SystemBarsAppearance(darkTheme)

    GabTheme(darkTheme = darkTheme) {
        var screen by rememberSaveable { mutableStateOf(Screen.HOME) }
        var focusRequested by remember { mutableStateOf(false) }
        val snackbar = remember { SnackbarHostState() }

        val session = controller.session
        val page by session.state.collectAsStateWithLifecycle()

        LaunchedEffect(session) {
            session.events.collect { event ->
                val message = when (event) {
                    is EngineEvent.NavigationBlocked ->
                        "Link do tipo \"${event.scheme}:\" bloqueado por segurança."

                    is EngineEvent.DownloadUnavailable ->
                        "O gerenciador de downloads chega na Etapa 2."
                }
                snackbar.showSnackbar(message)
            }
        }

        val open: (String) -> Unit = { input ->
            val target = UrlInputClassifier.classify(input, settings.searchEngine)
            if (target != null) {
                controller.session.loadUrl(target.url)
                screen = Screen.BROWSER
            }
        }

        BackHandler(enabled = screen != Screen.HOME) {
            if (screen == Screen.BROWSER && page.canGoBack && page.error == null) {
                session.goBack()
            } else {
                screen = Screen.HOME
            }
        }

        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            snackbarHost = { SnackbarHost(snackbar) },
            bottomBar = {
                GabBottomBar(
                    current = screen,
                    hasOpenPage = page.url.isNotEmpty(),
                    onSelect = { screen = it },
                    onSearch = {
                        if (screen != Screen.BROWSER) screen = Screen.HOME
                        focusRequested = true
                    },
                )
            },
        ) { padding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .consumeWindowInsets(padding)
                    .imePadding(),
            ) {
                when (screen) {
                    Screen.HOME -> HomeScreen(
                        sites = sites,
                        focusRequested = focusRequested,
                        onFocusConsumed = { focusRequested = false },
                        onOpen = open,
                        onOpenTools = { screen = Screen.TOOLS },
                    )

                    Screen.BROWSER -> BrowserScreen(
                        session = session,
                        page = page,
                        sites = sites,
                        focusRequested = focusRequested,
                        onFocusConsumed = { focusRequested = false },
                        onSubmit = open,
                        onHome = { screen = Screen.HOME },
                        onRecover = { controller.recover() },
                    )

                    Screen.TABS -> TabsScreen(
                        page = page,
                        onOpenCurrent = { screen = Screen.BROWSER },
                    )

                    Screen.TOOLS -> ToolsScreen()

                    Screen.SETTINGS -> SettingsScreen(
                        settings = settings,
                        settingsRepository = settingsRepository,
                    )
                }
            }
        }
    }
}

@Composable
private fun GabBottomBar(
    current: Screen,
    hasOpenPage: Boolean,
    onSelect: (Screen) -> Unit,
    onSearch: () -> Unit,
) {
    NavigationBar(
        containerColor = MaterialTheme.colorScheme.surface,
        tonalElevation = 0.dp,
    ) {
        NavigationBarItem(
            selected = current == Screen.HOME,
            onClick = { onSelect(Screen.HOME) },
            icon = { Icon(Icons.Filled.Home, contentDescription = null) },
            label = { Text("Início") },
        )
        NavigationBarItem(
            selected = false,
            onClick = onSearch,
            icon = { Icon(Icons.Filled.Search, contentDescription = null) },
            label = { Text("Pesquisa") },
        )
        NavigationBarItem(
            selected = current == Screen.TABS,
            onClick = { onSelect(Screen.TABS) },
            icon = { TabCountIcon(count = if (hasOpenPage) 1 else 0) },
            label = { Text("Abas") },
        )
        NavigationBarItem(
            selected = current == Screen.TOOLS,
            onClick = { onSelect(Screen.TOOLS) },
            icon = { Icon(Icons.Filled.Build, contentDescription = null) },
            label = { Text("Ferramentas") },
        )
        NavigationBarItem(
            selected = current == Screen.SETTINGS,
            onClick = { onSelect(Screen.SETTINGS) },
            icon = { Icon(Icons.Filled.Settings, contentDescription = null) },
            label = { Text("Ajustes") },
        )
    }
}

/** Quadradinho com o número de abas abertas, como nos navegadores móveis. */
@Composable
private fun TabCountIcon(count: Int) {
    val color = LocalContentColor.current
    Surface(
        modifier = Modifier.size(22.dp),
        shape = RoundedCornerShape(6.dp),
        color = Color.Transparent,
        contentColor = color,
        border = BorderStroke(2.dp, color),
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(text = count.toString(), fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
    }
}

/** Ícones da barra de status e de navegação acompanham o tema escolhido no app. */
@Composable
private fun SystemBarsAppearance(darkTheme: Boolean) {
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            val controller = WindowCompat.getInsetsController(window, view)
            controller.isAppearanceLightStatusBars = !darkTheme
            controller.isAppearanceLightNavigationBars = !darkTheme
        }
    }
}
