package com.gabbrowser.android

import android.app.Activity
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.gabbrowser.core.data.SiteRepository
import com.gabbrowser.core.engine.EngineSession
import com.gabbrowser.core.engine.VisitListener
import com.gabbrowser.core.engine.WebViewSession
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

/**
 * Dono da sessão de navegação. Na Etapa 1 existe uma única sessão;
 * o gerenciador de abas da Etapa 2 passa a manter várias.
 */
class BrowserController(
    private val activity: Activity,
    private val sites: SiteRepository,
    private val scope: CoroutineScope,
) {
    private val visitListener = VisitListener { url, title ->
        scope.launch { sites.recordVisit(url, title) }
    }

    var session: EngineSession by mutableStateOf(createSession())
        private set

    private fun createSession(): EngineSession =
        WebViewSession(activity).also { it.visitListener = visitListener }

    /** Recria a sessão depois que o processo de renderização caiu. */
    fun recover() {
        val url = session.state.value.url
        session.destroy()
        session = createSession()
        if (url.isNotEmpty()) session.loadUrl(url)
    }

    fun onResume() = session.onResume()

    fun onPause() = session.onPause()

    fun destroy() = session.destroy()
}
