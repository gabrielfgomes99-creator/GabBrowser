package com.gabbrowser.android.ui

import android.content.Intent
import android.view.ViewGroup
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.gabbrowser.core.data.SiteRepository
import com.gabbrowser.core.engine.ConnectionSecurity
import com.gabbrowser.core.engine.EngineSession
import com.gabbrowser.core.engine.PageError
import com.gabbrowser.core.engine.PageState
import kotlinx.coroutines.launch

@Composable
fun BrowserScreen(
    session: EngineSession,
    page: PageState,
    sites: SiteRepository,
    focusRequested: Boolean,
    onFocusConsumed: () -> Unit,
    onSubmit: (String) -> Unit,
    onHome: () -> Unit,
    onRecover: () -> Unit,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val bookmarked by remember(page.url) { sites.isBookmarked(page.url) }
        .collectAsStateWithLifecycle(initialValue = false)

    Column(Modifier.fillMaxSize()) {
        BrowserTopBar(
            page = page,
            bookmarked = bookmarked,
            focusRequested = focusRequested,
            onFocusConsumed = onFocusConsumed,
            onSubmit = onSubmit,
            onBack = { session.goBack() },
            onForward = { session.goForward() },
            onReload = { session.reload() },
            onStop = { session.stop() },
            onHome = onHome,
            onShare = {
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_SUBJECT, page.title)
                    putExtra(Intent.EXTRA_TEXT, page.url)
                }
                context.startActivity(Intent.createChooser(send, "Compartilhar página"))
            },
            onToggleBookmark = {
                val url = page.url
                val title = page.title
                scope.launch {
                    if (bookmarked) sites.removeBookmark(url) else sites.addBookmark(url, title)
                }
            },
        )

        if (page.isLoading) {
            LinearProgressIndicator(
                progress = { page.progress / 100f },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(2.dp),
            )
        }

        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
        ) {
            key(session) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = {
                        session.view.also { view ->
                            (view.parent as? ViewGroup)?.removeView(view)
                        }
                    },
                )
            }

            val error = page.error
            if (error != null) {
                ErrorPanel(
                    error = error,
                    onRetry = { if (error is PageError.RendererCrashed) onRecover() else session.reload() },
                    onHome = onHome,
                )
            }
        }
    }
}

@Composable
private fun BrowserTopBar(
    page: PageState,
    bookmarked: Boolean,
    focusRequested: Boolean,
    onFocusConsumed: () -> Unit,
    onSubmit: (String) -> Unit,
    onBack: () -> Unit,
    onForward: () -> Unit,
    onReload: () -> Unit,
    onStop: () -> Unit,
    onHome: () -> Unit,
    onShare: () -> Unit,
    onToggleBookmark: () -> Unit,
) {
    var menuOpen by remember { mutableStateOf(false) }

    Surface(color = MaterialTheme.colorScheme.surface, shadowElevation = 2.dp) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 2.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onBack, enabled = page.canGoBack, modifier = Modifier.size(40.dp)) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Voltar")
            }
            IconButton(onClick = onForward, enabled = page.canGoForward, modifier = Modifier.size(40.dp)) {
                Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = "Avançar")
            }

            AddressPill(
                page = page,
                focusRequested = focusRequested,
                onFocusConsumed = onFocusConsumed,
                onSubmit = onSubmit,
                onReload = onReload,
                onStop = onStop,
                modifier = Modifier.weight(1f),
            )

            Box {
                IconButton(onClick = { menuOpen = true }, modifier = Modifier.size(40.dp)) {
                    Icon(Icons.Filled.MoreVert, contentDescription = "Menu de ferramentas")
                }
                DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                    DropdownMenuItem(
                        text = { Text(if (bookmarked) "Remover dos favoritos" else "Adicionar aos favoritos") },
                        leadingIcon = { Icon(Icons.Filled.Star, contentDescription = null) },
                        enabled = page.url.startsWith("https://"),
                        onClick = {
                            menuOpen = false
                            onToggleBookmark()
                        },
                    )
                    DropdownMenuItem(
                        text = { Text("Compartilhar página") },
                        leadingIcon = { Icon(Icons.Filled.Share, contentDescription = null) },
                        enabled = page.url.isNotEmpty(),
                        onClick = {
                            menuOpen = false
                            onShare()
                        },
                    )
                    DropdownMenuItem(
                        text = { Text("Página inicial") },
                        leadingIcon = { Icon(Icons.Filled.Home, contentDescription = null) },
                        onClick = {
                            menuOpen = false
                            onHome()
                        },
                    )
                }
            }
        }
    }
}

@Composable
private fun AddressPill(
    page: PageState,
    focusRequested: Boolean,
    onFocusConsumed: () -> Unit,
    onSubmit: (String) -> Unit,
    onReload: () -> Unit,
    onStop: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val focusManager = LocalFocusManager.current
    val focusRequester = remember { FocusRequester() }
    var focused by remember { mutableStateOf(false) }
    var draft by remember { mutableStateOf(TextFieldValue("")) }

    LaunchedEffect(focusRequested) {
        if (focusRequested) {
            focusRequester.requestFocus()
            onFocusConsumed()
        }
    }

    // Fora de edição, mostra só o host: é a parte do endereço que identifica o site.
    val shown = if (focused) draft else TextFieldValue(displayHost(page.url))

    Surface(
        modifier = modifier.height(44.dp),
        shape = RoundedCornerShape(22.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
    ) {
        Row(
            modifier = Modifier.padding(start = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            SecurityIcon(page.security)
            Spacer(Modifier.width(8.dp))
            BasicTextField(
                value = shown,
                onValueChange = { if (focused) draft = it },
                modifier = Modifier
                    .weight(1f)
                    .focusRequester(focusRequester)
                    .onFocusChanged { state ->
                        if (state.isFocused && !focused) {
                            draft = TextFieldValue(page.url, TextRange(0, page.url.length))
                        }
                        focused = state.isFocused
                    },
                singleLine = true,
                textStyle = MaterialTheme.typography.bodyLarge.copy(
                    color = MaterialTheme.colorScheme.onSurface,
                ),
                cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                keyboardOptions = KeyboardOptions(
                    capitalization = KeyboardCapitalization.None,
                    imeAction = ImeAction.Go,
                ),
                keyboardActions = KeyboardActions(
                    onGo = {
                        val text = draft.text
                        focusManager.clearFocus()
                        if (text.isNotBlank()) onSubmit(text)
                    },
                ),
            )
            if (page.isLoading) {
                IconButton(onClick = onStop, modifier = Modifier.size(40.dp)) {
                    Icon(Icons.Filled.Close, contentDescription = "Cancelar carregamento")
                }
            } else {
                IconButton(onClick = onReload, modifier = Modifier.size(40.dp)) {
                    Icon(Icons.Filled.Refresh, contentDescription = "Atualizar")
                }
            }
        }
    }
}

@Composable
private fun SecurityIcon(security: ConnectionSecurity) {
    when (security) {
        ConnectionSecurity.SECURE -> Icon(
            imageVector = Icons.Filled.Lock,
            contentDescription = "Conexão segura (HTTPS)",
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(18.dp),
        )

        ConnectionSecurity.CERTIFICATE_ERROR -> Icon(
            imageVector = Icons.Filled.Warning,
            contentDescription = "Certificado inválido",
            tint = MaterialTheme.colorScheme.error,
            modifier = Modifier.size(18.dp),
        )

        ConnectionSecurity.NONE -> Icon(
            imageVector = Icons.Filled.Info,
            contentDescription = "Conexão ainda não verificada",
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(18.dp),
        )
    }
}

@Composable
private fun ErrorPanel(
    error: PageError,
    onRetry: () -> Unit,
    onHome: () -> Unit,
) {
    val title: String
    val body: String
    val canRetry: Boolean
    when (error) {
        is PageError.Certificate -> {
            title = "Conexão não segura"
            body = "O GabBrowser bloqueou ${error.host} porque ${error.reason}. " +
                "Alguém pode estar tentando se passar por este site, então não há opção de continuar."
            canRetry = false
        }

        is PageError.InsecureOnly -> {
            title = "Site sem HTTPS"
            body = "${error.host} só funciona sem criptografia. Nesta versão o GabBrowser abre apenas " +
                "conexões HTTPS; o acesso com aviso chega junto com o GabShield."
            canRetry = false
        }

        is PageError.Network -> {
            title = "Não foi possível abrir a página"
            body = error.description.ifBlank { "Verifique sua conexão e tente de novo." }
            canRetry = true
        }

        is PageError.RendererCrashed -> {
            title = "A página parou de responder"
            body = "O processo que exibia esta página foi encerrado. Recarregue para continuar."
            canRetry = true
        }
    }

    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Spacer(Modifier.height(48.dp))
            Icon(
                imageVector = Icons.Filled.Warning,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.error,
                modifier = Modifier.size(52.dp),
            )
            Spacer(Modifier.height(16.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.onBackground,
                textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(8.dp))
            Text(
                text = body,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(24.dp))
            if (canRetry) {
                Button(onClick = onRetry) { Text("Tentar novamente") }
                Spacer(Modifier.height(8.dp))
            }
            OutlinedButton(onClick = onHome) { Text("Voltar ao início") }
        }
    }
}
