package com.gabbrowser.core.data

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Index
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "history", indices = [Index("url"), Index("visitedAt")])
data class HistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val url: String,
    val title: String,
    val visitedAt: Long,
)

@Entity(tableName = "bookmarks", indices = [Index(value = ["url"], unique = true)])
data class BookmarkEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val url: String,
    val title: String,
    val createdAt: Long,
)

data class MostVisitedRow(
    val url: String,
    val title: String,
    val visits: Int,
)

@Dao
interface HistoryDao {
    @Insert
    suspend fun insert(entry: HistoryEntity): Long

    @Query(
        "SELECT * FROM history WHERE id IN (SELECT MAX(id) FROM history GROUP BY url) " +
            "ORDER BY visitedAt DESC LIMIT :limit",
    )
    fun recent(limit: Int): Flow<List<HistoryEntity>>

    @Query(
        "SELECT url, MAX(title) AS title, COUNT(*) AS visits FROM history " +
            "GROUP BY url ORDER BY visits DESC, MAX(visitedAt) DESC LIMIT :limit",
    )
    fun mostVisited(limit: Int): Flow<List<MostVisitedRow>>
}

@Dao
interface BookmarkDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(bookmark: BookmarkEntity): Long

    @Query("DELETE FROM bookmarks WHERE url = :url")
    suspend fun deleteByUrl(url: String)

    @Query("SELECT * FROM bookmarks ORDER BY createdAt DESC")
    fun all(): Flow<List<BookmarkEntity>>

    @Query("SELECT EXISTS(SELECT 1 FROM bookmarks WHERE url = :url)")
    fun isBookmarked(url: String): Flow<Boolean>
}

@Database(
    entities = [HistoryEntity::class, BookmarkEntity::class],
    version = 1,
    exportSchema = false,
)
abstract class GabDatabase : RoomDatabase() {
    abstract fun historyDao(): HistoryDao

    abstract fun bookmarkDao(): BookmarkDao
}
