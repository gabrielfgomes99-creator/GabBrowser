package com.gabbrowser.core.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.gabbrowser.core.common.SearchEngine
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

enum class ThemeMode(val id: String, val displayName: String) {
    SYSTEM("system", "Seguir o sistema"),
    LIGHT("light", "Claro"),
    DARK("dark", "Escuro");

    companion object {
        fun fromId(id: String?): ThemeMode = entries.firstOrNull { it.id == id } ?: SYSTEM
    }
}

data class UserSettings(
    val searchEngine: SearchEngine = SearchEngine.GOOGLE,
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
)

private val Context.gabDataStore: DataStore<Preferences> by preferencesDataStore(name = "gab_settings")

class SettingsRepository(context: Context) {

    private val store = context.applicationContext.gabDataStore

    val settings: Flow<UserSettings> = store.data
        .catch { error ->
            if (error is IOException) emit(emptyPreferences()) else throw error
        }
        .map { prefs ->
            UserSettings(
                searchEngine = SearchEngine.fromId(prefs[KEY_SEARCH_ENGINE]),
                themeMode = ThemeMode.fromId(prefs[KEY_THEME]),
            )
        }

    suspend fun setSearchEngine(engine: SearchEngine) {
        store.edit { it[KEY_SEARCH_ENGINE] = engine.id }
    }

    suspend fun setThemeMode(mode: ThemeMode) {
        store.edit { it[KEY_THEME] = mode.id }
    }

    private companion object {
        val KEY_SEARCH_ENGINE = stringPreferencesKey("search_engine")
        val KEY_THEME = stringPreferencesKey("theme_mode")
    }
}
