package com.gabbrowser.core.data

import android.content.Context
import androidx.room.Room
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

data class SiteLink(
    val url: String,
    val title: String,
)

/** Favoritos e histórico. Tudo fica somente no aparelho. */
class SiteRepository(database: GabDatabase) {

    private val history = database.historyDao()
    private val bookmarkDao = database.bookmarkDao()

    val bookmarks: Flow<List<SiteLink>> =
        bookmarkDao.all().map { list -> list.map { SiteLink(it.url, it.title) } }

    val recentHistory: Flow<List<SiteLink>> =
        history.recent(limit = 6).map { list -> list.map { SiteLink(it.url, it.title) } }

    val mostVisited: Flow<List<SiteLink>> =
        history.mostVisited(limit = 8).map { list -> list.map { SiteLink(it.url, it.title) } }

    fun isBookmarked(url: String): Flow<Boolean> = bookmarkDao.isBookmarked(url)

    suspend fun recordVisit(url: String, title: String) {
        history.insert(HistoryEntity(url = url, title = title, visitedAt = System.currentTimeMillis()))
    }

    suspend fun addBookmark(url: String, title: String) {
        bookmarkDao.insert(BookmarkEntity(url = url, title = title, createdAt = System.currentTimeMillis()))
    }

    suspend fun removeBookmark(url: String) {
        bookmarkDao.deleteByUrl(url)
    }
}

object GabData {
    fun siteRepository(context: Context): SiteRepository {
        val database = Room.databaseBuilder(
            context.applicationContext,
            GabDatabase::class.java,
            "gabbrowser.db",
        ).build()
        return SiteRepository(database)
    }
}
