package com.gabbrowser.core.common

import com.gabbrowser.core.common.NavigationPolicy.Decision
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class NavigationPolicyTest {

    @Test
    fun httpsEhPermitido() {
        assertEquals(Decision.Allow, NavigationPolicy.evaluate("https://exemplo.com"))
        assertEquals(Decision.Allow, NavigationPolicy.evaluate("HTTPS://EXEMPLO.COM"))
        assertEquals(Decision.Allow, NavigationPolicy.evaluate("about:blank"))
    }

    @Test
    fun httpEhReescritoParaHttps() {
        assertEquals(
            Decision.UpgradeToHttps("https://exemplo.com/a?b=1"),
            NavigationPolicy.evaluate("http://exemplo.com/a?b=1"),
        )
    }

    @Test
    fun outrosEsquemasSaoBloqueados() {
        val blocked = listOf(
            "file:///data/data/com.gabbrowser.android/databases/gabbrowser.db",
            "content://com.android.contacts/contacts",
            "javascript:alert(document.cookie)",
            "data:text/html,<script>alert(1)</script>",
            "intent://scan/#Intent;scheme=zxing;end",
            "market://details?id=x",
            "ftp://exemplo.com",
            "sem-esquema",
        )
        blocked.forEach { url ->
            assertTrue("$url deveria ser bloqueada", NavigationPolicy.evaluate(url) is Decision.Block)
        }
        assertEquals(Decision.Block("file"), NavigationPolicy.evaluate("file:///x"))
    }
}
