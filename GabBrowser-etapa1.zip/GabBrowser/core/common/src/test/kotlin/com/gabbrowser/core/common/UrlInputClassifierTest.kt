package com.gabbrowser.core.common

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class UrlInputClassifierTest {

    private fun classify(input: String) = UrlInputClassifier.classify(input, SearchEngine.DUCKDUCKGO)

    private fun assertSite(input: String, expectedUrl: String) {
        val target = classify(input)
        assertTrue("$input deveria ser site, foi $target", target is NavigationTarget.Site)
        assertEquals(expectedUrl, target!!.url)
    }

    private fun assertSearch(input: String) {
        val target = classify(input)
        assertTrue("$input deveria ser pesquisa, foi $target", target is NavigationTarget.Search)
        assertTrue(target!!.url.startsWith("https://duckduckgo.com/?q="))
    }

    @Test
    fun entradaVaziaNaoNavega() {
        assertNull(classify(""))
        assertNull(classify("   "))
    }

    @Test
    fun urlsCompletas() {
        assertSite("https://exemplo.com/a?b=1", "https://exemplo.com/a?b=1")
        assertSite("http://exemplo.com", "http://exemplo.com")
        assertSite("HTTPS://Exemplo.com", "HTTPS://Exemplo.com")
    }

    @Test
    fun urlsIncompletasRecebemHttps() {
        assertSite("exemplo.com", "https://exemplo.com")
        assertSite("www.exemplo.com.br/pagina", "https://www.exemplo.com.br/pagina")
        assertSite("exemplo.com:8443/x", "https://exemplo.com:8443/x")
        assertSite("localhost:8080", "https://localhost:8080")
        assertSite("192.168.0.1", "https://192.168.0.1")
        assertSite("pão.com.br", "https://pão.com.br")
    }

    @Test
    fun pesquisasComuns() {
        assertSearch("receita de bolo")
        assertSearch("kotlin")
        assertSearch("3.14")
        assertSearch("999.1.1.1")
        assertSearch("exemplo.com tem promoção")
    }

    @Test
    fun caracteresEspeciaisSaoCodificados() {
        val target = classify("c# & 50% de desconto?")
        assertTrue(target is NavigationTarget.Search)
        assertEquals(
            "https://duckduckgo.com/?q=c%23+%26+50%25+de+desconto%3F",
            target!!.url,
        )
    }

    @Test
    fun esquemasPerigososViramPesquisa() {
        assertSearch("javascript:alert(1)")
        assertSearch("file:///data/data/app/arquivo")
        assertSearch("data:text/html,<h1>x</h1>")
        assertSearch("content://provedor/dado")
        assertSearch("intent://abrir#Intent;end")
    }

    @Test
    fun credenciaisNoEnderecoViramPesquisa() {
        assertSearch("https://banco.com@site-falso.com/login")
        assertSearch("banco.com@site-falso.com")
    }

    @Test
    fun mecanismoEscolhidoEhRespeitado() {
        val google = UrlInputClassifier.classify("gab browser", SearchEngine.GOOGLE)
        assertEquals("https://www.google.com/search?q=gab+browser", google!!.url)
        val bing = UrlInputClassifier.classify("gab browser", SearchEngine.BING)
        assertEquals("https://www.bing.com/search?q=gab+browser", bing!!.url)
    }
}
