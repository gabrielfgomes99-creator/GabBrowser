package com.gabbrowser.core.common

import java.net.IDN

sealed interface NavigationTarget {
    val url: String

    data class Site(override val url: String) : NavigationTarget

    data class Search(val query: String, override val url: String) : NavigationTarget
}

/**
 * Decide se o texto digitado na barra é um endereço ou uma pesquisa.
 *
 * Regras de segurança:
 * - só http/https viram navegação; javascript:, data:, file:, intent: etc. viram pesquisa;
 * - endereços com "usuario@host" viram pesquisa (truque comum de phishing);
 * - endereços sem esquema recebem https://.
 */
object UrlInputClassifier {

    private val SCHEME = Regex("^([a-zA-Z][a-zA-Z0-9+.-]*):(.*)$")
    private val PORT_AND_REST = Regex("^\\d{1,5}([/?#].*)?$")
    private val PORT_SUFFIX = Regex(":\\d{1,5}$")
    private val LABEL = Regex("^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?$")
    private val IPV4 = Regex("^(\\d{1,3})\\.(\\d{1,3})\\.(\\d{1,3})\\.(\\d{1,3})$")
    private val ALPHA_TLD = Regex("^[a-z]{2,}$")

    fun classify(rawInput: String, engine: SearchEngine): NavigationTarget? {
        val input = rawInput.trim()
        if (input.isEmpty()) return null
        if (input.any { it.isWhitespace() }) return search(input, engine)

        val scheme = SCHEME.find(input)
        if (scheme != null) {
            val name = scheme.groupValues[1].lowercase()
            val rest = scheme.groupValues[2]
            if ((name == "http" || name == "https") && rest.startsWith("//")) {
                val host = hostOf(rest.removePrefix("//"))
                return if (host.isNotEmpty()) NavigationTarget.Site(input) else search(input, engine)
            }
            // "localhost:8080" parece um esquema, mas é host:porta. Qualquer outro esquema vira pesquisa.
            if (!PORT_AND_REST.matches(rest)) return search(input, engine)
        }

        return if (looksLikeHost(hostOf(input))) {
            NavigationTarget.Site("https://$input")
        } else {
            search(input, engine)
        }
    }

    private fun search(query: String, engine: SearchEngine): NavigationTarget =
        NavigationTarget.Search(query, engine.searchUrl(query))

    /** Extrai o host de "host[:porta][/caminho]". Devolve "" quando há credenciais ou IPv6. */
    internal fun hostOf(withoutScheme: String): String {
        val authority = withoutScheme.takeWhile { it != '/' && it != '?' && it != '#' }
        if (authority.contains('@') || authority.startsWith("[")) return ""
        return authority.replace(PORT_SUFFIX, "").lowercase().trimEnd('.')
    }

    internal fun looksLikeHost(host: String): Boolean {
        if (host.isEmpty()) return false
        if (host == "localhost") return true

        val ipv4 = IPV4.find(host)
        if (ipv4 != null) return ipv4.groupValues.drop(1).all { it.toInt() <= 255 }

        val ascii = try {
            IDN.toASCII(host).lowercase()
        } catch (e: IllegalArgumentException) {
            return false
        }
        val labels = ascii.split('.')
        if (labels.size < 2) return false
        if (!labels.all { LABEL.matches(it) }) return false
        val tld = labels.last()
        return ALPHA_TLD.matches(tld) || tld.startsWith("xn--")
    }
}
