package com.gabbrowser.core.common

import java.net.URLEncoder

/**
 * Mecanismos de pesquisa disponíveis. Para adicionar outro, basta incluir uma
 * nova entrada com o prefixo da URL de busca.
 */
enum class SearchEngine(
    val id: String,
    val displayName: String,
    private val queryPrefix: String,
) {
    GOOGLE("google", "Google", "https://www.google.com/search?q="),
    BING("bing", "Bing", "https://www.bing.com/search?q="),
    DUCKDUCKGO("duckduckgo", "DuckDuckGo", "https://duckduckgo.com/?q=");

    fun searchUrl(query: String): String = queryPrefix + URLEncoder.encode(query, "UTF-8")

    companion object {
        fun fromId(id: String?): SearchEngine = entries.firstOrNull { it.id == id } ?: GOOGLE
    }
}
