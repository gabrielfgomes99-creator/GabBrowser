package com.gabbrowser.core.common

/**
 * Política de esquemas de URL aplicada a toda navegação do motor.
 *
 * - https: permitido.
 * - http: reescrito para https (o app não aceita tráfego sem criptografia).
 * - about:blank: permitido.
 * - todo o resto (file:, content:, javascript:, data:, intent:, market:...): bloqueado.
 */
object NavigationPolicy {

    sealed interface Decision {
        data object Allow : Decision

        data class UpgradeToHttps(val url: String) : Decision

        data class Block(val scheme: String) : Decision
    }

    fun evaluate(url: String): Decision {
        val trimmed = url.trim()
        val lower = trimmed.lowercase()
        return when {
            lower.startsWith("https://") -> Decision.Allow
            lower.startsWith("http://") -> Decision.UpgradeToHttps("https://" + trimmed.substring(7))
            lower == "about:blank" -> Decision.Allow
            else -> Decision.Block(lower.substringBefore(':', "desconhecido").take(20))
        }
    }
}
