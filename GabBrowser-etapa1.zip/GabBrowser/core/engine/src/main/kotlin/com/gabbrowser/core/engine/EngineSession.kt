package com.gabbrowser.core.engine

import android.view.View
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow

enum class ConnectionSecurity { NONE, SECURE, CERTIFICATE_ERROR }

sealed interface PageError {
    data class Network(val description: String) : PageError

    data class Certificate(val host: String, val reason: String) : PageError

    data class InsecureOnly(val host: String) : PageError

    data object RendererCrashed : PageError
}

data class PageState(
    val url: String = "",
    val title: String = "",
    val progress: Int = 0,
    val isLoading: Boolean = false,
    val canGoBack: Boolean = false,
    val canGoForward: Boolean = false,
    val security: ConnectionSecurity = ConnectionSecurity.NONE,
    val error: PageError? = null,
)

sealed interface EngineEvent {
    data class NavigationBlocked(val scheme: String) : EngineEvent

    data object DownloadUnavailable : EngineEvent
}

fun interface VisitListener {
    fun onVisit(url: String, title: String)
}

/**
 * Contrato do motor de navegação. O app só conversa com esta interface, então
 * trocar o motor (por exemplo, para GeckoView) não exige mexer nas telas.
 */
interface EngineSession {
    val state: StateFlow<PageState>
    val events: SharedFlow<EngineEvent>
    val view: View
    var visitListener: VisitListener?

    fun loadUrl(url: String)
    fun reload()
    fun stop()
    fun goBack()
    fun goForward()
    fun onResume()
    fun onPause()
    fun destroy()
}
