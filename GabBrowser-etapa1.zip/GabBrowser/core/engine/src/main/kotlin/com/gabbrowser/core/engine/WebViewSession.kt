package com.gabbrowser.core.engine

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.net.http.SslError
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.GeolocationPermissions
import android.webkit.PermissionRequest
import android.webkit.RenderProcessGoneDetail
import android.webkit.SslErrorHandler
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.WebViewCompat
import com.gabbrowser.core.common.NavigationPolicy
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

/**
 * Sessão de navegação sobre o Android System WebView, com configuração endurecida:
 *
 * - erros de certificado nunca são ignorados (a carga é sempre cancelada);
 * - conteúdo misto (http dentro de https) é bloqueado;
 * - páginas não acessam arquivos locais nem content providers;
 * - nenhuma interface JavaScript nativa é exposta (sem addJavascriptInterface);
 * - cookies de terceiros desligados;
 * - pedidos de câmera, microfone e localização são negados (a tela de permissões chega na Etapa 3);
 * - Navegação Segura do WebView ligada.
 *
 * Deve ser criada com o contexto da Activity e usada somente na thread principal.
 */
class WebViewSession(context: Context) : EngineSession {

    private val _state = MutableStateFlow(PageState())
    override val state: StateFlow<PageState> = _state.asStateFlow()

    private val _events = MutableSharedFlow<EngineEvent>(extraBufferCapacity = 8)
    override val events: SharedFlow<EngineEvent> = _events.asSharedFlow()

    override var visitListener: VisitListener? = null

    private val webView = WebView(context)
    override val view: View get() = webView

    /** Host da navegação principal em andamento, para reconhecer erros de certificado da página. */
    private var pendingHost: String? = null

    /** URL cuja carga falhou; evita que eventos tardios da mesma carga apaguem o erro. */
    private var failedUrl: String? = null

    private var lastUpgradedUrl: String? = null
    private var lastRecordedUrl: String? = null
    private var destroyed = false

    init {
        configure()
    }

    @SuppressLint("SetJavaScriptEnabled")
    @Suppress("DEPRECATION")
    private fun configure() {
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true

            allowFileAccess = false
            allowContentAccess = false
            allowFileAccessFromFileURLs = false
            allowUniversalAccessFromFileURLs = false

            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            safeBrowsingEnabled = true

            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(false)
            setGeolocationEnabled(false)
            mediaPlaybackRequiresUserGesture = true

            builtInZoomControls = true
            displayZoomControls = false
            loadWithOverviewMode = true
            useWideViewPort = true
        }

        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(webView, false)
        }

        webView.webViewClient = Client()
        webView.webChromeClient = Chrome()
        webView.setDownloadListener { _, _, _, _, _ ->
            _events.tryEmit(EngineEvent.DownloadUnavailable)
        }
    }

    override fun loadUrl(url: String) {
        if (destroyed) return
        when (val decision = NavigationPolicy.evaluate(url)) {
            is NavigationPolicy.Decision.Allow -> start(url.trim())
            is NavigationPolicy.Decision.UpgradeToHttps -> start(decision.url)
            is NavigationPolicy.Decision.Block -> _events.tryEmit(EngineEvent.NavigationBlocked(decision.scheme))
        }
    }

    private fun start(url: String) {
        clearFailure()
        lastUpgradedUrl = null
        pendingHost = hostOf(url)
        _state.update {
            it.copy(url = url, isLoading = true, progress = 0, security = ConnectionSecurity.NONE)
        }
        webView.loadUrl(url)
    }

    override fun reload() {
        if (destroyed) return
        val current = _state.value
        if (current.error != null && current.url.isNotEmpty()) {
            start(current.url)
        } else {
            clearFailure()
            webView.reload()
        }
    }

    override fun stop() {
        if (destroyed) return
        webView.stopLoading()
        _state.update { it.copy(isLoading = false) }
    }

    override fun goBack() {
        if (destroyed || !webView.canGoBack()) return
        clearFailure()
        webView.goBack()
    }

    override fun goForward() {
        if (destroyed || !webView.canGoForward()) return
        clearFailure()
        webView.goForward()
    }

    override fun onResume() {
        if (!destroyed) webView.onResume()
    }

    override fun onPause() {
        if (!destroyed) webView.onPause()
    }

    override fun destroy() {
        if (destroyed) return
        destroyed = true
        visitListener = null
        (webView.parent as? ViewGroup)?.removeView(webView)
        webView.stopLoading()
        webView.destroy()
    }

    private fun clearFailure() {
        failedUrl = null
        _state.update { it.copy(error = null) }
    }

    private fun fail(error: PageError, url: String?, security: ConnectionSecurity) {
        failedUrl = url
        _state.update { it.copy(error = error, isLoading = false, security = security) }
    }

    private fun hostOf(url: String?): String? = url?.let { Uri.parse(it).host }

    private fun securityOf(url: String?): ConnectionSecurity =
        if (url != null && url.startsWith("https://", ignoreCase = true)) {
            ConnectionSecurity.SECURE
        } else {
            ConnectionSecurity.NONE
        }

    private inner class Client : WebViewClient() {

        override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
            if (request == null) return true
            val target = request.url?.toString() ?: return true
            val decision = NavigationPolicy.evaluate(target)

            if (!request.isForMainFrame) {
                return decision !is NavigationPolicy.Decision.Allow
            }

            return when (decision) {
                is NavigationPolicy.Decision.Allow -> {
                    clearFailure()
                    pendingHost = hostOf(target)
                    false
                }

                is NavigationPolicy.Decision.UpgradeToHttps -> {
                    if (decision.url == lastUpgradedUrl) {
                        // O site devolve para http depois do upgrade: só funciona sem criptografia.
                        fail(
                            PageError.InsecureOnly(hostOf(target).orEmpty()),
                            decision.url,
                            ConnectionSecurity.NONE,
                        )
                    } else {
                        clearFailure()
                        lastUpgradedUrl = decision.url
                        pendingHost = hostOf(decision.url)
                        webView.loadUrl(decision.url)
                    }
                    true
                }

                is NavigationPolicy.Decision.Block -> {
                    _events.tryEmit(EngineEvent.NavigationBlocked(decision.scheme))
                    true
                }
            }
        }

        override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
            if (url == null) return
            if (url != failedUrl) clearFailure()
            _state.update {
                it.copy(
                    url = url,
                    isLoading = true,
                    security = if (it.error == null) ConnectionSecurity.NONE else it.security,
                )
            }
        }

        override fun doUpdateVisitedHistory(view: WebView?, url: String?, isReload: Boolean) {
            if (url == null) return
            _state.update {
                it.copy(
                    url = url,
                    canGoBack = webView.canGoBack(),
                    canGoForward = webView.canGoForward(),
                    security = if (it.error == null) securityOf(url) else it.security,
                )
            }
        }

        override fun onPageFinished(view: WebView?, url: String?) {
            lastUpgradedUrl = null
            val title = webView.title.orEmpty()
            _state.update {
                it.copy(
                    title = title,
                    isLoading = false,
                    progress = 100,
                    canGoBack = webView.canGoBack(),
                    canGoForward = webView.canGoForward(),
                    security = if (it.error == null) securityOf(url) else it.security,
                )
            }

            val finished = url ?: return
            val isWebPage = finished.startsWith("https://", ignoreCase = true)
            if (_state.value.error == null && isWebPage && finished != lastRecordedUrl) {
                lastRecordedUrl = finished
                visitListener?.onVisit(finished, title)
            }
        }

        override fun onReceivedSslError(view: WebView?, handler: SslErrorHandler?, error: SslError?) {
            // Nunca prosseguir com certificado inválido.
            handler?.cancel()

            val errorHost = hostOf(error?.url) ?: return
            val isPageItself = errorHost == pendingHost || errorHost == hostOf(_state.value.url)
            if (isPageItself) {
                fail(
                    PageError.Certificate(errorHost, describeSslError(error)),
                    error?.url,
                    ConnectionSecurity.CERTIFICATE_ERROR,
                )
            }
        }

        override fun onReceivedError(
            view: WebView?,
            request: WebResourceRequest?,
            error: WebResourceError?,
        ) {
            if (request == null || !request.isForMainFrame) return
            val current = _state.value.error
            if (current is PageError.Certificate || current is PageError.InsecureOnly) return
            fail(
                PageError.Network(error?.description?.toString().orEmpty()),
                request.url?.toString(),
                ConnectionSecurity.NONE,
            )
        }

        override fun onRenderProcessGone(view: WebView?, detail: RenderProcessGoneDetail?): Boolean {
            // Devolver true evita que o app inteiro seja encerrado junto com o renderizador.
            fail(PageError.RendererCrashed, _state.value.url, ConnectionSecurity.NONE)
            return true
        }
    }

    private inner class Chrome : WebChromeClient() {

        override fun onProgressChanged(view: WebView?, newProgress: Int) {
            _state.update { it.copy(progress = newProgress) }
        }

        override fun onReceivedTitle(view: WebView?, title: String?) {
            _state.update { it.copy(title = title.orEmpty()) }
        }

        override fun onPermissionRequest(request: PermissionRequest?) {
            request?.deny()
        }

        override fun onGeolocationPermissionsShowPrompt(
            origin: String?,
            callback: GeolocationPermissions.Callback?,
        ) {
            callback?.invoke(origin, false, false)
        }
    }

    private fun describeSslError(error: SslError?): String = when (error?.primaryError) {
        SslError.SSL_EXPIRED -> "o certificado expirou"
        SslError.SSL_IDMISMATCH -> "o certificado pertence a outro site"
        SslError.SSL_UNTRUSTED -> "a autoridade que emitiu o certificado não é confiável"
        SslError.SSL_NOTYETVALID -> "o certificado ainda não é válido"
        SslError.SSL_DATE_INVALID -> "a data do certificado é inválida"
        else -> "o certificado é inválido"
    }

    companion object {
        /** Pacote e versão do WebView do sistema, para exibir em Configurações. */
        fun engineDescription(context: Context): String? {
            val info = WebViewCompat.getCurrentWebViewPackage(context) ?: return null
            return "${info.packageName} ${info.versionName}"
        }
    }
}
