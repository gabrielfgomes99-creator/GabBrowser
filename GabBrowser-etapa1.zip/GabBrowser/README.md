# GabBrowser

**Navegue livre. Navegue seguro.**

Navegador Android nativo em Kotlin e Jetpack Compose, sobre o Android System WebView.

## Estado atual: Etapa 1 (fundação)

> Este código ainda **não foi compilado nem executado**. Ele foi escrito e revisado sem acesso a um
> compilador Kotlin ou ao Android SDK. A primeira compilação acontece no GitHub Actions; erros que
> aparecerem lá precisam ser corrigidos antes de qualquer teste no aparelho.

### O que existe no código

- Tela inicial com logotipo, barra de pesquisa, favoritos, mais acessados e histórico recente.
- Barra de endereço que distingue endereço de pesquisa, completa URLs sem `https://` e codifica
  caracteres especiais.
- Escolha do mecanismo de pesquisa: Google, Bing ou DuckDuckGo.
- Navegação: voltar, avançar, atualizar, cancelar, indicador HTTPS, compartilhar, favoritar.
- Histórico e favoritos gravados no aparelho.
- Tema claro e escuro com a paleta da marca; ícone do app em vetor.
- Base de segurança: só HTTPS, certificado inválido sempre bloqueado, esquemas perigosos bloqueados,
  sem acesso a arquivos locais, cookies de terceiros desligados, pedidos de câmera/microfone/localização negados.

### O que ainda não existe

Várias abas, abas anônimas, downloads, GabShield, GabClean, GabAI, GabFlow, GabOne, GabReader, GabScan,
GabSaver, gerenciador de senhas, vídeo em tela cheia, envio de arquivos em formulários, abrir links vindos
de outros apps e APK de release assinado. A tela **Ferramentas** do app mostra em que etapa cada item entra.

Sites que só funcionam em `http://` não abrem nesta etapa (ver `docs/DECISOES.md`, D2).

## Como gerar o APK pelo GitHub (sem computador)

1. Envie este projeto para um repositório no GitHub, na branch `main`.
2. Abra a aba **Actions** do repositório e espere o fluxo **Build GabBrowser** terminar.
3. Na página da execução, baixe o artefato **GabBrowser-debug-apk** e extraia o `.apk`.
4. No celular, abra o `.apk` e permita a instalação de apps dessa origem.

Se a execução ficar vermelha, o erro de compilação está no passo que falhou; copie a mensagem para corrigir.

## Como compilar no Android Studio

Abra a pasta do projeto, aguarde a sincronização do Gradle e rode o módulo `app`.
Requer JDK 17 ou mais novo. Pela linha de comando, com Gradle 8.9 instalado:

```
gradle :core:common:test
gradle :app:assembleDebug
```

O APK sai em `app/build/outputs/apk/debug/`.

## Estrutura

```
app/                 telas e ligação entre módulos
core/common/         regras puras (barra de endereço, política de navegação) + testes
core/engine/         contrato do motor e implementação WebView
core/data/           Room e DataStore
core/designsystem/   tema, cores e logotipo
docs/DECISOES.md     registro das decisões técnicas
```

## Roteiro

1. **Fundação** — esta etapa.
2. **Navegador** — abas, favoritos com pastas, histórico completo, downloads, navegação privada.
3. **Segurança** — GabShield, GabClean, permissões, HTTP com aviso.
4. **Diferenciais** — GabAI, GabFlow, GabOne, GabReader, GabScan, GabSaver.
5. **Finalização** — otimização, testes em aparelho, auditoria de segurança (OWASP MASVS), assinatura e APK de release.
